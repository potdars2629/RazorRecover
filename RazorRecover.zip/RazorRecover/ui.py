from pathlib import Path
import pandas as pd
import streamlit as st
from recovery_engine import enrich_dataframe

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "payments.csv"

@st.cache_data
def load_data():
    return pd.read_csv(DATA_FILE)

@st.cache_data
def get_failed(df):
    return enrich_dataframe(df[df["status"] == "Failed"].copy())


def apply_theme():
    st.markdown("""
    <style>
    :root {
      --glacial:#C7F0EC;
      --tidal:#9ABDB9;
      --spruce:#6D8A87;
      --forest:#405855;
      --midnight:#132523;
      --ink:#0C1716;
      --text:#F4FBFA;
      --muted:#C7D8D5;
      --radius:18px;
    }

    html, body, [class*="css"] { color:var(--text); }
    .stApp {
      background:
        radial-gradient(circle at 85% 8%, rgba(154,189,185,.16), transparent 26%),
        radial-gradient(circle at 15% 92%, rgba(109,138,135,.12), transparent 30%),
        linear-gradient(135deg, #0E1E1C 0%, var(--midnight) 48%, #1D3633 100%);
      color:var(--text);
    }
    .block-container { max-width:1320px; padding-top:1.35rem; padding-bottom:3rem; }
    [data-testid="stHeader"] { background:rgba(19,37,35,.88); backdrop-filter:blur(12px); }
    [data-testid="stSidebar"] {
      background:linear-gradient(180deg,#0D1B1A 0%,#132523 55%,#1C3431 100%);
      border-right:1px solid rgba(199,240,236,.12);
    }
    [data-testid="stSidebar"] * { color:var(--text); }
    [data-testid="stSidebar"] .block-container { padding-top:1rem; }

    /* Hide Streamlit's auto-generated page list so filenames never appear in the UI. */
    [data-testid="stSidebarNav"] { display:none !important; }

    .rr-brand {
      padding:1.15rem 1rem 1rem;
      border:1px solid rgba(199,240,236,.14);
      border-radius:20px;
      background:linear-gradient(145deg,rgba(64,88,85,.72),rgba(19,37,35,.92));
      margin-bottom:1rem;
      box-shadow:0 16px 38px rgba(0,0,0,.22);
    }
    .rr-brand .title { font-size:1.3rem; font-weight:800; color:var(--glacial); letter-spacing:.01em; }
    .rr-brand .sub { font-size:.79rem; color:var(--muted); margin-top:.25rem; line-height:1.45; }
    .rr-nav-title { font-size:.72rem; text-transform:uppercase; letter-spacing:.12em; color:var(--tidal); font-weight:800; margin:.25rem 0 .5rem; }

    [data-testid="stPageLink"] a {
      border-radius:12px;
      padding:.58rem .7rem;
      margin:.14rem 0;
      color:var(--text) !important;
      text-decoration:none !important;
      border:1px solid transparent;
      transition:.18s ease;
    }
    [data-testid="stPageLink"] a:hover {
      background:rgba(64,88,85,.68);
      border-color:rgba(199,240,236,.12);
      transform:translateX(2px);
    }

    .rr-status {
      margin-top:1rem;
      padding:.78rem .85rem;
      border-radius:14px;
      background:rgba(64,88,85,.48);
      border:1px solid rgba(199,240,236,.12);
      color:var(--muted);
      font-size:.78rem;
    }
    .rr-status strong { color:var(--glacial); }

    .rr-hero {
      padding:1.9rem 2rem;
      border:1px solid rgba(199,240,236,.14);
      border-radius:24px;
      background:linear-gradient(135deg,rgba(64,88,85,.78),rgba(19,37,35,.95) 58%,rgba(109,138,135,.42));
      margin-bottom:1.25rem;
      box-shadow:0 18px 42px rgba(0,0,0,.22);
      position:relative;
      overflow:hidden;
    }
    .rr-hero:after {
      content:"";
      position:absolute;
      width:250px;
      height:250px;
      right:-70px;
      top:-120px;
      border-radius:50%;
      background:rgba(199,240,236,.08);
    }
    .rr-kicker { font-size:.74rem; font-weight:800; letter-spacing:.13em; text-transform:uppercase; color:var(--glacial); }
    .rr-hero h1 { color:var(--text); font-size:2.35rem; line-height:1.07; margin:.35rem 0 .55rem; }
    .rr-hero p { font-size:1.01rem; color:var(--muted); max-width:880px; margin:0; line-height:1.65; }

    .rr-card {
      padding:1.12rem 1.15rem;
      border:1px solid rgba(199,240,236,.13);
      border-radius:18px;
      background:linear-gradient(145deg,rgba(64,88,85,.58),rgba(19,37,35,.92));
      min-height:124px;
      box-shadow:0 10px 26px rgba(0,0,0,.16);
    }
    .rr-card h3 { color:var(--text); margin:.06rem 0 .35rem; font-size:1.03rem; }
    .rr-card p { margin:0; color:var(--muted); font-size:.9rem; line-height:1.55; }
    .rr-card .rr-kicker { color:var(--tidal); }

    h1,h2,h3,h4,h5,h6,p,label { color:var(--text); }
    div[data-testid="stMetric"] {
      border:1px solid rgba(199,240,236,.12);
      padding:15px 16px;
      border-radius:17px;
      background:linear-gradient(145deg,rgba(64,88,85,.66),rgba(19,37,35,.94));
      box-shadow:0 9px 24px rgba(0,0,0,.14);
    }
    div[data-testid="stMetric"] label { color:var(--tidal) !important; font-weight:650; }
    div[data-testid="stMetricValue"] { color:var(--glacial); }
    div[data-testid="stDataFrame"] { border-radius:16px; overflow:hidden; border:1px solid rgba(199,240,236,.12); }

    div[data-baseweb="select"] > div,
    .stTextInput input,
    .stNumberInput input,
    .stTextArea textarea {
      background-color:rgba(19,37,35,.92) !important;
      color:var(--text) !important;
      border-color:rgba(199,240,236,.18) !important;
    }

    .stButton > button {
      border-radius:12px;
      font-weight:750;
      background:var(--forest);
      color:var(--text);
      border:1px solid var(--spruce);
      box-shadow:none;
    }
    .stButton > button:hover { background:var(--spruce); border-color:var(--tidal); color:white; }
    .stButton > button[kind="primary"] { background:var(--glacial); color:var(--midnight); border-color:var(--glacial); }
    .stButton > button[kind="primary"]:hover { background:var(--tidal); color:var(--ink); border-color:var(--tidal); }

    [data-testid="stAlert"] { background:rgba(64,88,85,.47); color:var(--text); border:1px solid rgba(199,240,236,.14); }
    [data-testid="stExpander"] { border-color:rgba(199,240,236,.12) !important; background:rgba(19,37,35,.30); }
    [data-testid="stSlider"] [role="slider"] { background:var(--glacial) !important; }
    [data-testid="stProgressBar"] > div > div { background:var(--glacial) !important; }
    hr { border-color:rgba(199,240,236,.12); }
    .rr-footer { text-align:center; color:var(--spruce); font-size:.8rem; padding-top:1.6rem; }
    </style>
    """, unsafe_allow_html=True)


def sidebar(active: str):
    with st.sidebar:
        st.markdown("""
        <div class="rr-brand">
          <div class="title">RazorRecover</div>
          <div class="sub">Intelligent payment recovery for failed transactions.</div>
        </div>
        <div class="rr-nav-title">Workspace</div>
        """, unsafe_allow_html=True)

        # Manual links keep navigation professional and prevent emoji/filename encoding issues.
        st.page_link("app.py", label="Overview")
        st.page_link("pages/1_Command_Center.py", label="Command Center")
        st.page_link("pages/2_AI_Decision.py", label="AI Decision")
        st.page_link("pages/3_Recovery_Autopilot.py", label="Recovery Autopilot")
        st.page_link("pages/4_Failure_Intelligence.py", label="Failure Intelligence")
        st.page_link("pages/5_Impact_Simulator.py", label="Impact Simulator")
        st.page_link("pages/6_API_Demo.py", label="API Demo")

        st.markdown(f"""
        <div class="rr-status">
          <strong>{active}</strong><br>
          Demo environment · No live payments are triggered.
        </div>
        """, unsafe_allow_html=True)


def hero(kicker: str, title: str, subtitle: str):
    st.markdown(f"""
    <div class="rr-hero">
      <div class="rr-kicker">{kicker}</div>
      <h1>{title}</h1>
      <p>{subtitle}</p>
    </div>
    """, unsafe_allow_html=True)


def footer():
    st.markdown('<div class="rr-footer">RazorRecover 2.3 · Payment Recovery Intelligence · Demo data only</div>', unsafe_allow_html=True)
