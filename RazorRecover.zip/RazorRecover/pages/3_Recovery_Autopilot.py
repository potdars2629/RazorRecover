import streamlit as st
from ui import apply_theme, sidebar, hero, load_data, get_failed, footer

st.set_page_config(page_title="Autopilot • RazorRecover", page_icon=":material/autorenew:", layout="wide")
apply_theme(); sidebar("Recovery Autopilot")
df=load_data(); failed=get_failed(df)
hero("Automation", "Recovery Autopilot", "Turn AI decisions into a safe, prioritized recovery campaign instead of blindly retrying every failed transaction.")

with st.container(border=True):
    st.markdown("### Campaign guardrails")
    a,b,c=st.columns(3)
    with a: min_prob=st.slider("Minimum recovery probability",30,95,55)
    with b: max_attempts=st.slider("Maximum previous attempts",1,4,3)
    with c: budget=st.number_input("Processing budget (₹)",min_value=1000,value=int(failed.amount.sum()),step=1000)

eligible=failed[(failed.recovery_probability>=min_prob)&(failed.attempt_count<=max_attempts)].sort_values("priority_score",ascending=False).copy()
eligible["cumulative_amount"]=eligible.amount.cumsum(); campaign=eligible[eligible.cumulative_amount<=budget].copy()
if campaign.empty and not eligible.empty: campaign=eligible.head(1)

x,y,z=st.columns(3)
x.metric("Payments Selected",len(campaign)); y.metric("Revenue Targeted",f"₹{campaign.amount.sum():,.0f}"); z.metric("Expected Recovery",f"₹{campaign.expected_recovery_value.sum():,.0f}")

if not campaign.empty:
    st.markdown("### Autopilot queue")
    st.dataframe(campaign[["payment_id","amount","failure_reason","recommended_action","retry_time","recovery_probability","priority_score"]],width="stretch",hide_index=True)
    if st.button("▶ Run Autopilot Demo",type="primary",width="stretch"):
        st.success(f"Autopilot created {len(campaign)} recovery journeys. Estimated recoverable revenue: ₹{campaign.expected_recovery_value.sum():,.0f}.")
        st.progress(min(100,int(campaign.recovery_probability.mean())))
        st.caption("Demo mode only — no real payment or customer communication is triggered.")
else:
    st.warning("No payments match these safety rules. Lower the probability threshold or increase allowed attempts.")
footer()
