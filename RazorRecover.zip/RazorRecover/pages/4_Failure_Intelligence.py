import streamlit as st
from ui import apply_theme, sidebar, hero, load_data, get_failed, footer

st.set_page_config(page_title="Failure Intelligence • RazorRecover", page_icon=":material/analytics:", layout="wide")
apply_theme(); sidebar("Failure Intelligence")
df=load_data(); failed=get_failed(df)
hero("Analytics", "Failure Intelligence", "Find where payment failures happen, which segments are most recoverable, and where recovery teams should act first.")

left,right=st.columns(2)
with left:
    st.markdown("### Failure frequency")
    st.bar_chart(failed.failure_reason.value_counts())
    st.markdown("### Average recovery probability")
    st.bar_chart(failed.groupby("failure_reason").recovery_probability.mean().sort_values(ascending=False))
with right:
    st.markdown("### Failed value by customer type")
    st.bar_chart(failed.groupby("customer_type").amount.sum().sort_values(ascending=False))
    st.markdown("### Attempts vs recoverability")
    st.line_chart(failed.groupby("attempt_count").recovery_probability.mean())

top_reason=failed.groupby("failure_reason").amount.sum().idxmax(); best_reason=failed.groupby("failure_reason").recovery_probability.mean().idxmax()
st.info(f"💡 **AI insight:** `{top_reason}` causes the highest failed revenue, while `{best_reason}` has the highest average recoverability. Prioritize high-value temporary failures first for faster revenue recovery.")
footer()
