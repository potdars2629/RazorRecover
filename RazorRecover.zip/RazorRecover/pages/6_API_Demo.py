import json
import streamlit as st
from ui import apply_theme, sidebar, hero, load_data, get_failed, footer
from recovery_engine import score_payment

st.set_page_config(page_title="API Demo • RazorRecover", page_icon=":material/api:", layout="wide")
apply_theme(); sidebar("API Demo")
df=load_data(); failed=get_failed(df)
hero("Integration", "Decision API Demo", "Show how RazorRecover can sit between a payment webhook and merchant recovery systems without changing the checkout experience.")

left,right=st.columns([.9,1.1])
with left:
    st.markdown("### Request")
    pid=st.selectbox("Payment",failed.payment_id.tolist())
    raw=df[df.payment_id==pid].iloc[0]
    st.code(json.dumps({"event":"payment.failed","payment_id":pid,"amount":int(raw.amount),"failure_reason":raw.failure_reason},indent=2),language="json")
with right:
    decision=score_payment(raw)
    st.markdown("### RazorRecover response")
    payload={"payment_id":pid,"decision":{"action":decision.action,"recovery_probability":decision.probability,"priority_score":decision.priority_score,"expected_recovery_value":decision.expected_recovery_value,"retry_time":decision.retry_time,"risk_level":decision.risk_level}}
    st.code(json.dumps(payload,indent=2),language="json")

st.markdown("### Production flow")
st.markdown("**Payment webhook → RazorRecover scoring → Retry scheduler / alternate-method prompt → Outcome tracking → Strategy tuning**")
st.info("This hackathon version simulates the decision API locally. A production deployment could expose the same engine through FastAPI/Flask and connect to payment gateway webhooks.")
footer()
