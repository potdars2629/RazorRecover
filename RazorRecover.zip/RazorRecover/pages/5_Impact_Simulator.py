import streamlit as st
from ui import apply_theme, sidebar, hero, load_data, get_failed, footer

st.set_page_config(page_title="Impact Simulator • RazorRecover", page_icon=":material/trending_up:", layout="wide")
apply_theme(); sidebar("Impact Simulator")
df=load_data(); failed=get_failed(df)
hero("Business Value", "Impact Simulator", "Convert recovery performance into a judge-friendly business story: recovered GMV, incremental uplift and annual opportunity.")

with st.container(border=True):
    st.markdown("### Merchant assumptions")
    a,b=st.columns(2)
    with a:
        monthly_tx=st.number_input("Monthly transactions",min_value=1000,value=100000,step=5000)
        failure_rate=st.slider("Payment failure rate",1.0,20.0,7.0,.5)
        current_manual=st.slider("Current/manual recovery rate",0.0,50.0,18.0,1.0)
    with b:
        avg_value=st.number_input("Average payment value (₹)",min_value=100,value=1800,step=100)
        recover_rate=st.slider("RazorRecover recovery rate",10.0,90.0,float(round(failed.recovery_probability.mean(),1)),1.0)

failed_tx=monthly_tx*failure_rate/100; failed_gmv=failed_tx*avg_value; ai=failed_gmv*recover_rate/100; manual=failed_gmv*current_manual/100; inc=ai-manual
s1,s2,s3,s4=st.columns(4)
s1.metric("Monthly Failed GMV",f"₹{failed_gmv/100000:.1f}L"); s2.metric("With RazorRecover",f"₹{ai/100000:.1f}L"); s3.metric("Incremental Recovery",f"₹{inc/100000:.1f}L"); s4.metric("Annual Upside",f"₹{inc*12/10000000:.2f}Cr")

st.markdown("### Pitch-ready impact")
st.progress(int(min(100,recover_rate)))
st.success(f"At these assumptions, RazorRecover can unlock approximately **₹{inc*12/10000000:.2f} crore of additional annual recovered GMV** compared with the current recovery process.")
footer()
