# RazorRecover 2.3

**Intelligent payment recovery for merchants and payment platforms.**

This version uses a clean multi-page Streamlit interface with a professional Midnight Green / Spruce palette. The navigation is rendered manually with plain text labels, so Windows/VS Code encoding cannot corrupt sidebar icons or page names.

## UI palette

- Midnight Green — `#132523`
- Deep Forest — `#405855`
- Spruce — `#6D8A87`
- Tidal Pool — `#9ABDB9`
- Glacial Mist — `#C7F0EC`

## Main features

- Recovery Command Center
- Explainable AI decision engine
- Priority and recoverability scoring
- Recovery Autopilot with guardrails
- Failure Intelligence analytics
- Business Impact Simulator
- Integration / API demo

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

On Windows PowerShell, from the RazorRecover folder:

```powershell
py -m streamlit run app.py
```

## Recommended demo flow

1. Command Center
2. AI Decision
3. Recovery Autopilot
4. Impact Simulator
5. API Demo
