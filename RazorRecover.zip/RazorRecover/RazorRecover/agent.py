from pathlib import Path
import pandas as pd
from recovery_engine import score_payment

BASE_DIR = Path(__file__).resolve().parent
df = pd.read_csv(BASE_DIR / "data" / "payments.csv")
failed = df[df["status"] == "Failed"]

print("\n========== RAZORRECOVER 2.0 AI AGENT ==========\n")
for _, payment in failed.iterrows():
    d = score_payment(payment)
    print("Payment ID:", payment["payment_id"])
    print("Amount: ₹{:,.0f}".format(payment["amount"]))
    print("Failure Reason:", payment["failure_reason"])
    print("Recommended Action:", d.action_label)
    print("Recovery Probability:", d.probability, "%")
    print("Priority Score:", d.priority_score)
    print("Expected Recovery Value: ₹{:,.0f}".format(d.expected_recovery_value))
    print("Best Retry Time:", d.retry_time)
    print("Explanation:", d.explanation)
    print("-" * 60)
