from pathlib import Path
import pandas as pd
from recovery_engine import enrich_dataframe

BASE_DIR = Path(__file__).resolve().parent
df = pd.read_csv(BASE_DIR / "data" / "payments.csv")
failed = enrich_dataframe(df[df["status"] == "Failed"].copy())

print("========== RAZORRECOVER 2.0 ANALYSIS ==========")
print("Total transactions:", len(df))
print("Failed payments:", len(failed))
print("Failed revenue: ₹{:,.0f}".format(failed["amount"].sum()))
print("Expected recoverable revenue: ₹{:,.0f}".format(failed["expected_recovery_value"].sum()))
print("\nTop recovery queue:\n")
print(failed.sort_values("priority_score", ascending=False)[[
    "payment_id", "amount", "failure_reason", "recommended_action",
    "recovery_probability", "priority_score", "expected_recovery_value"
]].to_string(index=False))
