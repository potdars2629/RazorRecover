from dataclasses import dataclass, asdict
from typing import Dict
import math

ACTION_LABELS = {
    "SMART_RETRY": "Smart Retry",
    "WAIT_AND_RETRY": "Wait & Retry",
    "SWITCH_METHOD": "Switch Payment Method",
    "AUTHENTICATION_HELP": "Authentication Help",
    "CONTACT_BANK": "Contact Bank / Alternate Method",
    "ESCALATE": "Manual Review",
}

REASON_CONFIG = {
    "Insufficient Balance": {"action": "WAIT_AND_RETRY", "base": 0.62, "delay": "Tomorrow, 10:00 AM", "reason_weight": 0.58},
    "Network Error": {"action": "SMART_RETRY", "base": 0.88, "delay": "In 15 minutes", "reason_weight": 0.90},
    "Technical Error": {"action": "SMART_RETRY", "base": 0.84, "delay": "In 30 minutes", "reason_weight": 0.86},
    "Bank Declined": {"action": "SWITCH_METHOD", "base": 0.55, "delay": "Now", "reason_weight": 0.50},
    "Authentication Failed": {"action": "AUTHENTICATION_HELP", "base": 0.67, "delay": "Now", "reason_weight": 0.64},
    "Daily Limit Exceeded": {"action": "WAIT_AND_RETRY", "base": 0.70, "delay": "Tomorrow, 9:00 AM", "reason_weight": 0.68},
    "Card Expired": {"action": "SWITCH_METHOD", "base": 0.60, "delay": "Now", "reason_weight": 0.56},
    "Unknown": {"action": "ESCALATE", "base": 0.38, "delay": "Within 1 hour", "reason_weight": 0.35},
}

METHOD_BONUS = {"UPI": 0.05, "Card": 0.02, "NetBanking": 0.00, "Wallet": 0.04}
CUSTOMER_BONUS = {"VIP": 0.07, "Returning": 0.04, "New": -0.02}

@dataclass
class RecoveryDecision:
    action: str
    action_label: str
    probability: float
    priority_score: float
    expected_recovery_value: float
    retry_time: str
    risk_level: str
    explanation: str
    customer_message: str
    factors: Dict[str, float]


def _clip(x, low=0.05, high=0.98):
    return max(low, min(high, x))


def score_payment(payment) -> RecoveryDecision:
    reason = str(payment.get("failure_reason", "Unknown") or "Unknown")
    config = REASON_CONFIG.get(reason, REASON_CONFIG["Unknown"])
    amount = float(payment.get("amount", 0))
    history = float(payment.get("previous_success_rate", 0.5))
    attempts = int(payment.get("attempt_count", 1))
    method = str(payment.get("payment_method", ""))
    customer_type = str(payment.get("customer_type", "New"))

    reason_component = config["base"] * 0.42
    history_component = history * 0.38
    method_component = METHOD_BONUS.get(method, 0)
    customer_component = CUSTOMER_BONUS.get(customer_type, 0)
    attempt_penalty = max(0, attempts - 1) * 0.07

    probability = _clip(reason_component + history_component + method_component + customer_component - attempt_penalty)

    amount_factor = min(1.0, math.log1p(amount) / math.log1p(10000)) if amount > 0 else 0
    priority = 100 * (0.52 * probability + 0.30 * amount_factor + 0.18 * config["reason_weight"])
    expected_value = amount * probability

    if attempts >= 3 or probability < 0.38:
        risk = "High"
    elif attempts == 2 or probability < 0.62:
        risk = "Medium"
    else:
        risk = "Low"

    action = config["action"]
    explanation = _explanation(reason, history, attempts, method, customer_type, action)
    message = _message(reason, action, amount)

    factors = {
        "Failure recoverability": round(config["base"] * 100, 1),
        "Customer payment history": round(history * 100, 1),
        "Method adjustment": round(METHOD_BONUS.get(method, 0) * 100, 1),
        "Customer relationship": round(CUSTOMER_BONUS.get(customer_type, 0) * 100, 1),
        "Retry penalty": round(-attempt_penalty * 100, 1),
    }

    return RecoveryDecision(
        action=action,
        action_label=ACTION_LABELS[action],
        probability=round(probability * 100, 1),
        priority_score=round(priority, 1),
        expected_recovery_value=round(expected_value, 2),
        retry_time=config["delay"],
        risk_level=risk,
        explanation=explanation,
        customer_message=message,
        factors=factors,
    )


def _explanation(reason, history, attempts, method, customer_type, action):
    history_text = "strong" if history >= 0.8 else "moderate" if history >= 0.6 else "limited"
    retry_text = "first recovery attempt" if attempts <= 1 else f"attempt #{attempts}"
    return (
        f"The transaction failed because of {reason.lower()}. This customer has a {history_text} "
        f"historical success rate and this is {retry_text}. For a {method} payment from a "
        f"{customer_type.lower()} customer, {ACTION_LABELS[action].lower()} gives the best balance "
        "between conversion probability and avoiding unnecessary retry friction."
    )


def _message(reason, action, amount):
    amt = f"₹{amount:,.0f}"
    if action == "SMART_RETRY":
        return f"We couldn't complete your {amt} payment due to a temporary issue. No action is needed—we'll retry safely at the best time."
    if action == "WAIT_AND_RETRY":
        return f"Your {amt} payment needs another attempt. We'll remind you at the best retry time so you can complete it quickly."
    if action == "SWITCH_METHOD":
        return f"Your {amt} payment was not completed. Try UPI or another saved payment method for a faster successful checkout."
    if action == "AUTHENTICATION_HELP":
        return f"Your {amt} payment needs authentication. Re-open payment and complete the bank/OTP verification to continue."
    return f"We couldn't complete your {amt} payment. Our recovery team is reviewing it and will guide you to the safest next step."


def enrich_dataframe(df):
    out = df.copy()
    decisions = [asdict(score_payment(row)) for _, row in out.iterrows()]
    out["recommended_action"] = [d["action_label"] for d in decisions]
    out["recovery_probability"] = [d["probability"] for d in decisions]
    out["priority_score"] = [d["priority_score"] for d in decisions]
    out["expected_recovery_value"] = [d["expected_recovery_value"] for d in decisions]
    out["retry_time"] = [d["retry_time"] for d in decisions]
    out["risk_level"] = [d["risk_level"] for d in decisions]
    return out
