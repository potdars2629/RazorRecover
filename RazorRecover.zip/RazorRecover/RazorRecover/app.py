import streamlit as st
from ui import apply_theme, sidebar, hero, load_data, get_failed, footer

st.set_page_config(page_title="RazorRecover 2.0", page_icon="⚡", layout="wide", initial_sidebar_state="expanded")
apply_theme()
sidebar("Overview")

df = load_data()
failed = get_failed(df)
failed_revenue = failed["amount"].sum()
expected_recovery = failed["expected_recovery_value"].sum()
success_rate = (df["status"].eq("Success").sum() / len(df) * 100) if len(df) else 0
high_priority = failed["priority_score"].ge(70).sum()

hero("Hackathon Edition", "Recover failed payments before they become lost revenue.", "RazorRecover uses explainable AI to rank failed transactions, choose the next-best recovery action, and show the financial impact in real time.")

c1,c2,c3,c4 = st.columns(4)
c1.metric("Failed Revenue", f"₹{failed_revenue:,.0f}")
c2.metric("AI Recoverable", f"₹{expected_recovery:,.0f}", f"{(expected_recovery/failed_revenue*100 if failed_revenue else 0):.0f}% opportunity")
c3.metric("High Priority", int(high_priority))
c4.metric("Current Success Rate", f"{success_rate:.1f}%")

st.markdown("### Your recovery workflow")
cols = st.columns(3)
cards = [
    ("01", "📊 Command Center", "See failed revenue, priority queue and recovery opportunity."),
    ("02", "🧠 AI Decision", "Inspect one payment and understand why the model chose its action."),
    ("03", "🚀 Recovery Autopilot", "Build a safe recovery campaign using probability and retry rules."),
    ("04", "🔎 Failure Intelligence", "Discover failure patterns, customer segments and recoverability."),
    ("05", "🎯 Impact Simulator", "Translate recovery performance into monthly and annual business impact."),
    ("06", "🔌 API Demo", "Show judges how RazorRecover can integrate with a production payment stack."),
]
for i,(num,title,desc) in enumerate(cards):
    with cols[i%3]:
        st.markdown(f'<div class="rr-card"><div class="rr-kicker">STEP {num}</div><h3>{title}</h3><p>{desc}</p></div>', unsafe_allow_html=True)
        st.write("")

st.info("🏆 **Hackathon demo path:** Command Center → AI Decision → Recovery Autopilot → Impact Simulator → API Demo")
footer()
