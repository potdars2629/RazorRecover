from pathlib import Path
import pandas as pd
import streamlit as st
from recovery_engine import enrich_dataframe

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "payments.csv"

@st.cache_data
def load_data():
    return pd.read_csv(DATA_FILE)

@st.cache_data
def get_failed(df):
    return enrich_dataframe(df[df["status"] == "Failed"].copy())


def apply_theme():
    st.markdown("""
    <style>
    :root { --rr-radius: 18px; }
    .stApp { background: linear-gradient(180deg, rgba(99,102,241,.06), transparent 320px); }
    .block-container { max-width: 1320px; padding-top: 1.4rem; padding-bottom: 3rem; }
    [data-testid="stSidebar"] { border-right: 1px solid rgba(128,128,128,.14); }
    [data-testid="stSidebar"] .block-container { padding-top: 1.2rem; }
    .rr-brand { padding: 1rem 1rem .8rem; border-radius: 18px; background: linear-gradient(135deg,#111827,#312e81); color:white; margin-bottom: .9rem; box-shadow:0 10px 30px rgba(49,46,129,.18); }
    .rr-brand .title { font-size:1.25rem; font-weight:800; }
    .rr-brand .sub { font-size:.78rem; opacity:.72; margin-top:.2rem; }
    .rr-hero { padding: 1.8rem 2rem; border:1px solid rgba(128,128,128,.16); border-radius:24px; background:linear-gradient(135deg,rgba(79,70,229,.14),rgba(14,165,233,.06)); margin-bottom:1.2rem; box-shadow:0 12px 35px rgba(0,0,0,.04); }
    .rr-kicker { font-size:.75rem; font-weight:800; letter-spacing:.11em; text-transform:uppercase; opacity:.65; }
    .rr-hero h1 { font-size:2.45rem; line-height:1.05; margin:.35rem 0 .55rem; }
    .rr-hero p { font-size:1.03rem; opacity:.78; max-width:850px; margin:0; }
    .rr-card { padding:1.05rem 1.15rem; border:1px solid rgba(128,128,128,.16); border-radius:18px; background:rgba(255,255,255,.025); min-height:110px; }
    .rr-card h3 { margin:.05rem 0 .3rem; font-size:1.02rem; }
    .rr-card p { margin:0; opacity:.72; font-size:.9rem; }
    .rr-section { margin-top:.35rem; margin-bottom:.25rem; font-weight:750; font-size:1.1rem; }
    div[data-testid="stMetric"] { border:1px solid rgba(128,128,128,.15); padding:14px 16px; border-radius:16px; background:rgba(255,255,255,.02); }
    div[data-testid="stDataFrame"] { border-radius:16px; overflow:hidden; border:1px solid rgba(128,128,128,.14); }
    .stButton > button { border-radius:12px; font-weight:700; }
    .rr-footer { text-align:center; opacity:.55; font-size:.8rem; padding-top:1.5rem; }
    </style>
    """, unsafe_allow_html=True)


def sidebar(active: str):
    with st.sidebar:
        st.markdown("""
        <div class="rr-brand">
          <div class="title">⚡ RazorRecover</div>
          <div class="sub">AI payment recovery • Hackathon Edition</div>
        </div>
        """, unsafe_allow_html=True)
        st.caption(f"Current workspace: **{active}**")
        st.markdown("---")
        st.markdown("**Demo navigation**")
        st.caption("Use the pages above to move through the recovery journey.")
        st.markdown("---")
        st.success("● Demo system online")
        st.caption("No real payments or customer messages are triggered.")


def hero(kicker: str, title: str, subtitle: str):
    st.markdown(f"""
    <div class="rr-hero">
      <div class="rr-kicker">{kicker}</div>
      <h1>{title}</h1>
      <p>{subtitle}</p>
    </div>
    """, unsafe_allow_html=True)


def footer():
    st.markdown('<div class="rr-footer">RazorRecover 2.0 • Explainable AI • Demo data only</div>', unsafe_allow_html=True)
