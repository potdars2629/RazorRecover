import streamlit as st
import pandas as pd
from ui import apply_theme, sidebar, hero, load_data, get_failed, footer
from recovery_engine import score_payment

st.set_page_config(page_title="AI Decision • RazorRecover", page_icon="🧠", layout="wide")
apply_theme(); sidebar("AI Decision")
df=load_data(); failed=get_failed(df)
hero("Explainable AI", "Next-Best-Action Engine", "Select a failed transaction and RazorRecover explains the recovery probability, priority, action, retry time and customer communication.")

selected=st.selectbox("Select a failed payment",failed.payment_id.tolist())
raw=df[df.payment_id==selected].iloc[0]; decision=score_payment(raw)
a,b,c,d=st.columns(4)
a.metric("Recovery Probability",f"{decision.probability:.1f}%")
b.metric("Priority Score",f"{decision.priority_score:.1f}/100")
c.metric("Expected Recovery",f"₹{decision.expected_recovery_value:,.0f}")
d.metric("Risk",decision.risk_level)

left,right=st.columns([1.15,1])
with left:
    st.markdown("### AI recommendation")
    st.info(f"**{decision.action_label}**\n\n**Best retry time:** {decision.retry_time}\n\n{decision.explanation}")
    st.markdown("### Decision factor breakdown")
    factor_df=pd.DataFrame({"Signal":decision.factors.keys(),"Contribution":decision.factors.values()}).set_index("Signal")
    st.bar_chart(factor_df)
with right:
    st.markdown("### Customer communication")
    st.success(decision.customer_message)
    st.markdown("### Transaction context")
    st.json({"payment_id":raw.payment_id,"customer_id":raw.customer_id,"amount":int(raw.amount),"method":raw.payment_method,"failure_reason":raw.failure_reason,"customer_type":raw.customer_type,"previous_success_rate":float(raw.previous_success_rate),"attempt_count":int(raw.attempt_count)})
footer()
