import streamlit as st
from ui import apply_theme, sidebar, hero, load_data, get_failed, footer

st.set_page_config(page_title="Command Center • RazorRecover", page_icon="📊", layout="wide")
apply_theme(); sidebar("Command Center")
df=load_data(); failed=get_failed(df)
hero("Operations", "Recovery Command Center", "A revenue-first view of failed payments. Focus your team on transactions with the highest probability-adjusted recovery value.")

failed_revenue=failed.amount.sum(); expected=failed.expected_recovery_value.sum(); high=failed.priority_score.ge(70).sum()
a,b,c,d=st.columns(4)
a.metric("Failed Revenue", f"₹{failed_revenue:,.0f}")
b.metric("Expected Recovery", f"₹{expected:,.0f}")
c.metric("Failed Payments", len(failed))
d.metric("High Priority", int(high))

st.markdown("### Priority recovery queue")
queue=failed.sort_values(["priority_score","expected_recovery_value"],ascending=False)[["payment_id","customer_id","amount","failure_reason","payment_method","recovery_probability","priority_score","expected_recovery_value","recommended_action"]]
st.dataframe(queue,width="stretch",hide_index=True,column_config={
"recovery_probability":st.column_config.ProgressColumn("Recovery %",min_value=0,max_value=100,format="%.1f%%"),
"priority_score":st.column_config.ProgressColumn("Priority",min_value=0,max_value=100,format="%.1f"),
"amount":st.column_config.NumberColumn("Amount",format="₹%d"),
"expected_recovery_value":st.column_config.NumberColumn("Expected Value",format="₹%.0f")})

left,right=st.columns(2)
with left:
    st.markdown("### Failed value by reason")
    st.bar_chart(failed.groupby("failure_reason")["amount"].sum().sort_values(ascending=False))
with right:
    st.markdown("### Recovery opportunity by method")
    st.bar_chart(failed.groupby("payment_method")["expected_recovery_value"].sum().sort_values(ascending=False))
footer()
