# RazorRecover 2.0 ⚡

**AI-powered payment failure recovery for merchants and payment platforms.**

RazorRecover converts failed transactions into an intelligent, prioritized recovery pipeline. Instead of blindly retrying every failure, it estimates recovery probability, expected recoverable value, customer friction risk, the next-best action, and an optimal retry window.

## Hackathon features

- Explainable Recovery AI scoring
- Revenue-priority recovery queue
- Next-best-action engine
- Smart retry timing
- Recovery Autopilot with guardrails
- Personalized customer recovery messages
- Business Impact Simulator
- Failure Intelligence dashboard
- Integration-ready JSON API demo

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 2-minute judging demo

1. **Command Center:** show Failed Revenue vs AI Recoverable Revenue.
2. **AI Decision:** select different payments and demonstrate explainable next-best actions.
3. **Recovery Autopilot:** set recovery guardrails and run the demo campaign.
4. **Impact Simulator:** show projected annual recovered GMV for a large merchant.
5. **API Demo:** finish by showing how a webhook can consume RazorRecover decisions.

## Architecture

```text
Payment failure event
       ↓
Recovery scoring engine
       ↓
Probability + priority + expected value
       ↓
Next-best action + best retry time
       ↓
Autopilot / customer recovery journey
       ↓
Recovered revenue + outcome feedback
```

## Production roadmap

For production, replace the transparent scoring prototype with a model trained on historical recovery outcomes; add live payment-provider webhooks, idempotent retry execution, A/B testing, consent/policy guardrails, authentication, a database, and continuous model monitoring.
